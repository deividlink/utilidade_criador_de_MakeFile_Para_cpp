# Projeto; Make_O_File
# Author: Deivid K.L

# Obs. So funciona em S.O linux e no Termux;

# Remova o termux-elf-cleaner se for rodar no linux(ele aparece na função)

# createMakeFile() nas linhas 14 e 21(dentro da funçaos,contando \n)


# Programas Necessarios

# Clang

  pkg install clang

# Make

  pkg install make
